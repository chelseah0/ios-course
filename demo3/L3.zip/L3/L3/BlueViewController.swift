//
//  BlueViewController.swift
//  L3
//
//  Created by Omar Rasheed on 3/10/20.
//  Copyright © 2020 Cornell Appdev. All rights reserved.
//

import UIKit

class BlueViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .blue
        title = "Blue View Controller"
    }

}
